import styles from "./services_portal.module.css";
export default function Installation() {
  return (
    <div>
      <h2>Installation and regisration</h2>
    </div>
  );
}
