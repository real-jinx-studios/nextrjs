export default function FileFormatsSection() {
  return (
    <section className="section flex-center-center">
      <div className="table">
        <div className="table-header">shit</div>
        <div className="table-body">piss</div>
      </div>
    </section>
  );
}
