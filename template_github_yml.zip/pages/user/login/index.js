import LoginForm from "../../../components/forms/auth/loginForm";

export default function ServicePortal() {
  return <LoginForm />;
}
