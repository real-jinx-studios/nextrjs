import RegisterForm from "../../../components/forms/auth/registerForm";

export default function ServicePortal() {
  return <RegisterForm />;
}
