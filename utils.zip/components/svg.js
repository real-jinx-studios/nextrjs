import styles from "./homeMain.module.css";

/*
<svg className={styles.shape_top} preserveAspectRatio="none" viewBox="0 0 86 86"
     width="100%" height="185">
    <polygon points="0,0 0,86 86,86" style={{"fill":"#F03030"}}></polygon>
</svg>
<svg className={styles.shape_bottom} preserveAspectRatio="none" viewBox="0 0 86 86"
     width="100%" height="185">
    <polygon points="0,0 86,0 86,86" style={{"fill": "#F03030"}}></polygon>
</svg>*/
